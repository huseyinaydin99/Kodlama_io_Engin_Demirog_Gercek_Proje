﻿namespace Application.Services.FindeksService;

public interface IFindeksService
{
    short GetScore(string identityNumber);
}