﻿namespace Application.Features.Cars.Dtos;

public class DeletedCarDto
{
    public int Id { get; set; }
}