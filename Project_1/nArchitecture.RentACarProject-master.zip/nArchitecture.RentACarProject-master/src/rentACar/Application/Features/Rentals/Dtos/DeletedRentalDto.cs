﻿namespace Application.Features.Rentals.Dtos;

public class DeletedRentalDto
{
    public int Id { get; set; }
}