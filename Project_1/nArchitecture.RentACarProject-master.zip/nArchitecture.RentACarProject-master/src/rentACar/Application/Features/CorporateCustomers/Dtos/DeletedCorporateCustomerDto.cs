namespace Application.Features.CorporateCustomers.Dtos;

public class DeletedCorporateCustomerDto
{
    public int Id { get; set; }
}