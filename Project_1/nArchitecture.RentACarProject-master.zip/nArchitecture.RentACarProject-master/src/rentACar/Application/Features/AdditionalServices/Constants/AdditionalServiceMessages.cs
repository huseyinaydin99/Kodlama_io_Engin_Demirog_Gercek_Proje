namespace Application.Features.AdditionalServices.Constants;

public static class AdditionalServiceMessages
{
    public const string AdditionalServiceNotExists = "AdditionalService not exists.";
    public const string AdditionalServiceNameExists = "Additional service name exists.";
}