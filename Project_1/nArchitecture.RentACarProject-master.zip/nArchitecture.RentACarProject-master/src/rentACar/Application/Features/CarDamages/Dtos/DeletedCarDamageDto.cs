﻿namespace Application.Features.CarDamages.Dtos;

public class DeletedCarDamageDto
{
    public int Id { get; set; }
}