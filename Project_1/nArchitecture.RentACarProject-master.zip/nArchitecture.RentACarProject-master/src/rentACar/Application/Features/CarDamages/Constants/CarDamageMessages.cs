namespace Application.Features.CarDamages.Constants;

public static class CarDamageMessages
{
    public const string CarDamageNotExists = "CarDamage not exists.";
}