namespace Application.Features.Colors.Constants;

public static class ColorMessages
{
    public const string ColorNotExists = "Color not exists.";
    public const string ColorNameExists = "Color name exists.";
}