﻿namespace Application.Features.Colors.Dtos;

public class UpdatedColorDto
{
    public int Id { get; set; }
    public string Name { get; set; }
}