﻿namespace Application.Features.Colors.Dtos;

public class DeletedColorDto
{
    public int Id { get; set; }
}