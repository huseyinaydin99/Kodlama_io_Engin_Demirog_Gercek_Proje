namespace Application.Features.IndividualCustomers.Dtos;

public class DeletedIndividualCustomerDto
{
    public int Id { get; set; }
}