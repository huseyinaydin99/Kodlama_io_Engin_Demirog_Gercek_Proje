namespace Application.Features.FindeksCreditRates.Dtos;

public class UpdatedFindeksCreditRateDto
{
    public int Id { get; set; }
    public int Score { get; set; }
}