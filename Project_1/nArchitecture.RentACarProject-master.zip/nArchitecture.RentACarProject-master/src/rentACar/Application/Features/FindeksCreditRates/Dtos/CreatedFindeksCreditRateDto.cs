namespace Application.Features.FindeksCreditRates.Dtos;

public class CreatedFindeksCreditRateDto
{
    public int Id { get; set; }
    public int Score { get; set; }
}