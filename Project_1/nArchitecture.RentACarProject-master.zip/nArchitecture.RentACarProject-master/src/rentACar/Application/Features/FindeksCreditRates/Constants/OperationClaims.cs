﻿namespace Application.Features.FindeksCreditRates.Constants;

public static class OperationClaims
{
    public const string FindeksCreditScoreDelete = "additionalservice.delete";
}