namespace Application.Features.FindeksCreditRates.Constants;

public static class FindeksCreditRateMessage
{
    public const string FindeksCreditRateNotExists = "Findeks Credit Rate not exists.";
}