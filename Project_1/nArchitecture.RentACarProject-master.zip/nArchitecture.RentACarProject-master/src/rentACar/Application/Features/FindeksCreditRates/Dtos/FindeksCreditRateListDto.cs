namespace Application.Features.FindeksCreditRates.Dtos;

public class FindeksCreditRateListDto
{
    public int Id { get; set; }
    public int Score { get; set; }
}