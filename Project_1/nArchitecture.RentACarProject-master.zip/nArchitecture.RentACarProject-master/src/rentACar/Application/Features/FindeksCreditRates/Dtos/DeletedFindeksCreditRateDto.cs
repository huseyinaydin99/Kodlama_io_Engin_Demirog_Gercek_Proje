namespace Application.Features.FindeksCreditRates.Dtos;

public class DeletedFindeksCreditRateDto
{
    public int Id { get; set; }
}