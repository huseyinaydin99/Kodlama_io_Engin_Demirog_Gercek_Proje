namespace Application.Features.Invoices.Constants;

public static class InvoiceMessages
{
    public const string InvoiceNotExists = "Invoice not exists.";
}