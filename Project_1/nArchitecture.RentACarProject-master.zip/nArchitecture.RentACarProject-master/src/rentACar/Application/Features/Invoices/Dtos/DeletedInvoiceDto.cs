namespace Application.Features.Invoices.Dtos;

public class DeletedInvoiceDto
{
    public int Id { get; set; }
}