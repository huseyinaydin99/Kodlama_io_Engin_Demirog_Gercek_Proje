namespace Application.Features.RentalBranches.Dtos;

public class DeletedRentalBranchDto
{
    public int Id { get; set; }
}