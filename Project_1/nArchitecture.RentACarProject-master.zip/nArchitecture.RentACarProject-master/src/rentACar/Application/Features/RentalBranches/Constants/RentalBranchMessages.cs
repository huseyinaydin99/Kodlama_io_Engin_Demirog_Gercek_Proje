namespace Application.Features.RentalBranches.Constants;

public static class RentalBranchMessages
{
    public const string RentalBranchNotExists = "Rental Branch not exists.";
}