﻿namespace Application.Features.Brands.Dtos;

public class BrandListDto
{
    public int Id { get; set; }
    public string Name { get; set; }
}