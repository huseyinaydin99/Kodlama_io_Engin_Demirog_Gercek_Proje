﻿namespace Application.Features.Brands.Dtos;

public class DeletedBrandDto
{
    public int Id { get; set; }
}