namespace Application.Features.Brands.Constants;

public static class BrandMessages
{
    public const string BrandNotExists = "Brand not exists.";
    public const string BrandNameExists = "Brand name exists.";
}