﻿namespace Application.Features.Brands.Dtos;

public class UpdatedBrandDto
{
    public int Id { get; set; }
    public string Name { get; set; }
}