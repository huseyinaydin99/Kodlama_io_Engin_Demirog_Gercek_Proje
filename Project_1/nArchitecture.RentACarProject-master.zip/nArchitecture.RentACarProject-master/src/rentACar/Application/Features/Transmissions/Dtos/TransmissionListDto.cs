﻿namespace Application.Features.Transmissions.Dtos;

public class TransmissionListDto
{
    public int Id { get; set; }
    public string Name { get; set; }
}