﻿namespace Application.Features.Transmissions.Dtos;

public class DeletedTransmissionDto
{
    public int Id { get; set; }
}