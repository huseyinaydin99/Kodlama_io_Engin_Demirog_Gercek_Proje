namespace Application.Features.Transmissions.Constants;

public static class TransmissionMessages
{
    public const string TransmissionNotExists = "Transmission not exists.";
    public const string TransmissionNameExists = "Transmission name exists.";
}