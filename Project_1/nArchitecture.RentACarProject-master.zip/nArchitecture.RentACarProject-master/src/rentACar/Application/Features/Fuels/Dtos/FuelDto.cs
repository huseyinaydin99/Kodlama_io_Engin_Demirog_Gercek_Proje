﻿namespace Application.Features.Fuels.Dtos;

public class FuelDto
{
    public int Id { get; set; }
    public string Name { get; set; }
}