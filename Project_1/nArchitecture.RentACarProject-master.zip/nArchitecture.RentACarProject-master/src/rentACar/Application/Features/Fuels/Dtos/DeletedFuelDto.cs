﻿namespace Application.Features.Fuels.Dtos;

public class DeletedFuelDto
{
    public int Id { get; set; }
}