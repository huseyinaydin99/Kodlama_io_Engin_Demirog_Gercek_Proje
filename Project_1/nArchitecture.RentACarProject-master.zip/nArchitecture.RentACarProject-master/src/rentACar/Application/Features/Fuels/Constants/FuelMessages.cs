namespace Application.Features.Fuels.Constants;

public static class FuelMessages
{
    public const string FuelNotExists = "Fuel not exists.";
    public const string FuelNameExists = "Fuel name exists.";
}