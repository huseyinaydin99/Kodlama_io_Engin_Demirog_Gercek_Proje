namespace Application.Features.OperationClaims.Dtos;

public class OperationClaimListDto
{
    public int Id { get; set; }
    public string Name { get; set; }
}