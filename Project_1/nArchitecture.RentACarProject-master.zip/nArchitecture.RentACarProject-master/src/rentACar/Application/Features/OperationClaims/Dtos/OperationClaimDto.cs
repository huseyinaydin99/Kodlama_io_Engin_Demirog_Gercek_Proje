namespace Application.Features.OperationClaims.Dtos;

public class OperationClaimDto
{
    public int Id { get; set; }
    public string Name { get; set; }
}