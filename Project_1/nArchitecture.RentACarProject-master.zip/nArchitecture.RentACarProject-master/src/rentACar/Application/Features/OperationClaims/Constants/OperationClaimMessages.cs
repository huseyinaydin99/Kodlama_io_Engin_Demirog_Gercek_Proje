namespace Application.Features.OperationClaims.Constants;

public static class OperationClaimMessages
{
    public const string OperationClaimNotExists = "Operation Claim not exists.";
}