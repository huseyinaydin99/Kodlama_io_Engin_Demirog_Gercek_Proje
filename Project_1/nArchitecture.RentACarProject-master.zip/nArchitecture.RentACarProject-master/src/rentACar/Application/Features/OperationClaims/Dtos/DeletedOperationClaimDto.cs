namespace Application.Features.OperationClaims.Dtos;

public class DeletedOperationClaimDto
{
    public int Id { get; set; }
}