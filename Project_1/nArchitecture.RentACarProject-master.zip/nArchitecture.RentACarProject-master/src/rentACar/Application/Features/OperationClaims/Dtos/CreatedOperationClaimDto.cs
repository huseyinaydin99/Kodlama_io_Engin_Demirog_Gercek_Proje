namespace Application.Features.OperationClaims.Dtos;

public class CreatedOperationClaimDto
{
    public int Id { get; set; }
    public string Name { get; set; }
}