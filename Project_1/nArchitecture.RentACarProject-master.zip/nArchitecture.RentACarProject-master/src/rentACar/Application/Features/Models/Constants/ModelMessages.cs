namespace Application.Features.Models.Constants;

public static class ModelMessages
{
    public const string ModelNotExists = "Model not exists.";
}