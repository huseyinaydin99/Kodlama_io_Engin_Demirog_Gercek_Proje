﻿namespace Application.Features.Models.Dtos;

public class DeletedModelDto
{
    public int Id { get; set; }
}