﻿namespace Application.Features.Auths.Dtos;

public class RevokedTokenDto
{
    public int Id { get; set; }
    public string Token { get; set; }
}