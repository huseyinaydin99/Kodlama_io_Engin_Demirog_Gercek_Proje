﻿namespace Application.Features.Auths.Dtos;

public class RegisteredDto : RefreshedTokensDto
{
}