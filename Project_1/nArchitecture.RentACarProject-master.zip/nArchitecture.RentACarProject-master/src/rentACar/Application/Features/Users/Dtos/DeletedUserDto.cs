namespace Application.Features.Users.Dtos;

public class DeletedUserDto
{
    public int Id { get; set; }
}