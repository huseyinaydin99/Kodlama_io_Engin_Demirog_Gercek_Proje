namespace Application.Features.UserOperationClaims.Dtos;

public class DeletedUserOperationClaimDto
{
    public int Id { get; set; }
}