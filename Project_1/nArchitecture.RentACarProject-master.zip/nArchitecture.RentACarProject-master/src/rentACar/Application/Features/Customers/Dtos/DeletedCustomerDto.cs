namespace Application.Features.Customers.Dtos;

public class DeletedCustomerDto
{
    public int Id { get; set; }
}