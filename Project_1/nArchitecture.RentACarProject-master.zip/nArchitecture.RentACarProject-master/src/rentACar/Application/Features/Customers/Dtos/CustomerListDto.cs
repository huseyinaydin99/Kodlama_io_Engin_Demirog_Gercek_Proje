namespace Application.Features.Customers.Dtos;

public class CustomerListDto
{
    public int Id { get; set; }
    public int UserId { get; set; }
}