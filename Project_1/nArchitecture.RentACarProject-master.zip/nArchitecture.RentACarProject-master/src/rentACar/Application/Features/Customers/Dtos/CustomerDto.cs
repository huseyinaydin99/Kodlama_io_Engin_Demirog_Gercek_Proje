namespace Application.Features.Customers.Dtos;

public class CustomerDto
{
    public int Id { get; set; }
    public int UserId { get; set; }
}