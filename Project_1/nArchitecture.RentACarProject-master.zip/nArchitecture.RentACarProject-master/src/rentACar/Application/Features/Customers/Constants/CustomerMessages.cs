namespace Application.Features.Customers.Constants;

public static class CustomerMessages
{
    public const string CustomerNotExists = "Customer not exists.";
}