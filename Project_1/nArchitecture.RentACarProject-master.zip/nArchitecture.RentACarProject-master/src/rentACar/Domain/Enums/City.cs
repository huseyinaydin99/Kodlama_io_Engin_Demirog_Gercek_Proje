﻿namespace Domain.Enums;

public enum City
{
    Ankara = 6,
    Antalya = 7
}