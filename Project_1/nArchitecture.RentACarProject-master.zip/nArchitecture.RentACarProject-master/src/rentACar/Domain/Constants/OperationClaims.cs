﻿namespace Domain.Constants;

public static class OperationClaims
{
    public const string Admin = "admin";
}