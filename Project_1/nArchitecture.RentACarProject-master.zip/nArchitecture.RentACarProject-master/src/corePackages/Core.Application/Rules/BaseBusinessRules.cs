﻿namespace Core.Application.Rules
{
    public abstract class BaseBusinessRules
    {
    }
}
