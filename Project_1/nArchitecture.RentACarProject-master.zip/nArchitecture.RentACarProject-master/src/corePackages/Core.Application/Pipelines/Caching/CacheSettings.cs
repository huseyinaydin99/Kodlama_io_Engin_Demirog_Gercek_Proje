﻿namespace Core.Application.Pipelines.Caching;

public class CacheSettings
{
    public int SlidingExpiration { get; set; }
}