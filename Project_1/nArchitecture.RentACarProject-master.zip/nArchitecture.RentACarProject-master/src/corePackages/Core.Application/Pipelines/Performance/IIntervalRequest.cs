﻿namespace Core.Application.Pipelines.Performance;

public interface IIntervalRequest
{
    public int Interval { get; }
}
