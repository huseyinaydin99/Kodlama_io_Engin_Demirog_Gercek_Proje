﻿namespace Core.CrossCuttingConcerns.Logging.Serilog.ConfigurationModels;

public class FileLogConfiguration
{
    public string FolderPath { get; set; }
}