﻿namespace Core.Mailing;

public interface IMailService
{
    void SendMail(Mail mail);
}